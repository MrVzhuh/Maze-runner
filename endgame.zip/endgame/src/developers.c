#include "header.h"

void developers(int max_x, int max_y) {
    clear();
    mvwprintw(stdscr, max_y / 3.3, max_x /2.5 , "Artur 'anovatarskyi' Novotarskyi - team leader");
    mvwprintw(stdscr, max_y / 3, max_x /2.5 , "Valerii 'vynchuk' Ynchuk - level designer, tester");
    mvwprintw(stdscr, max_y / 2.6, max_x /2.5 , "Arthur 'aliashuk' Liashuk - senior c, tester");
    mvwprintw(stdscr, max_y / 2.4, max_x /2.5 , "Oleksii 'odiachenko' Diachenko - level designer, tester");
    mvwprintw(stdscr, max_y / 2.2, max_x /2.5 , "Vladislav 'vklepko' Klepko - level designer , tester");
    mvwprintw(stdscr, max_y / 2, max_x /2.5 , "Dmytro 'dpak' Pak - PR manager,  middle c, tester");
     while(true) {
         if (getch() == 27)
                return;
     }
}
