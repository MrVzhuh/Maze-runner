#include "header.h"

void game() {
    int player_x, player_y, key_x, key_y, exit_x, exit_y;
    char** our_male = create_male(&player_x, &player_y, &key_x, &key_y, &exit_x, &exit_y);
    bool key_flag = false;
    bool continue_play = true;
    while (continue_play) {
        clear();
        mvwprintw(stdscr, 0, 0, our_male[0]);
        for (int i = 1; i < 30; i++) {
            mvwprintw(stdscr, i, 0, "%c", our_male[i][0]);
            mvwprintw(stdscr, i, 59, "%c", our_male[i][59]);
        }
        mvwprintw(stdscr, 30, 0, our_male[30]);
        for (int i = -3; i < 4; i++) {
            if (player_y + i  > 0 && player_y + i < 30) {
                for (int j = -6; j < 7; j++) {
                    if (player_x + j > 0 && player_x + j < 59) {
                        if (player_x == player_x + j && player_y == player_y + i)
                            mvwprintw(stdscr, player_y, player_x, "P");
                        else { 
                            if (key_x == player_x + j && key_y == player_y + i && key_flag == false)
                                mvwprintw(stdscr, player_y + i, player_x + j, "K");
                            else
                                mvwprintw(stdscr, player_y + i, player_x + j, "%c", our_male[player_y + i][player_x +j]);
                            }
                    }
                }
            }
        }
        key_flag =( key_x == player_x && key_y == player_y) ? true : key_flag;
        
        if (player_x == exit_x && exit_y == player_y && key_flag == true)
            finish();
        switch (getch()) {
            case KEY_UP:
                if (our_male[player_y - 1][player_x] != '#')
                    player_y--;
                break;
            case KEY_DOWN:
                if (our_male[player_y + 1][player_x] != '#')
                    player_y++;
                break;
            case KEY_RIGHT:
                if (our_male[player_y][player_x + 1] != '#')
                    player_x++;
                break;
            case KEY_LEFT:
                if (our_male[player_y][player_x - 1] != '#')
                    player_x--;
                break;
            case 'q':
                continue_play = false;
                break;
        }
        refresh();        
    }
}

