#include "header.h"

int main() {
    int max_x, max_y;
    int element = 0;
    double choise = 4.5;
    initscr();
    keypad(stdscr, true);
    curs_set(0);
    noecho();
    getmaxyx(stdscr, max_y, max_x);
    intro();
    while (true) {
        clear();
        mvwprintw(stdscr, max_y / 6, max_x / 2 - 5, "MALE RUNNER");
        mvwprintw(stdscr, max_y / 4.5, max_x / 2 - 5, "Start");
        mvwprintw(stdscr, max_y / 3.5, max_x / 2 - 5, "Level - 1");
        mvwprintw(stdscr, max_y / 3, max_x / 2 - 5, "Exit");
        mvwprintw(stdscr, max_y / 2.5, max_x / 2 - 5, "Developers");
        mvwprintw(stdscr, max_y / choise, max_x / 2 - 6, ">");

        switch (getch()) {
            case KEY_UP:
                if (element > 0)
                    element--;
                break;
            case KEY_DOWN:
                if (element < 3)
                    element++;
                break;
            case ' ':
                switch(element) {
		    case (0):
                        game(); 
		        break;
		    case(2):
			clear();
                        return 0;
	            case(3):
			developers(max_x, max_y);
			break;
		}
                break;
            case 'q':
                return 0;
        }
        switch (element) {
            case 0:
                choise = 4.5;
                break;
            case 1:
                choise = 3.5;
                break;
            case 2:
                choise = 3;
                break;
            case 3:
                choise = 2.5;
                break;
        }
    }
    

    endwin();
}


