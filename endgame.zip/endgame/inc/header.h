#ifndef header
#define header

#include <ncurses.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

char** create_male();
void history();
void game();
void developers(int max_x, int max_y);
void intro();
void finish();
#endif
